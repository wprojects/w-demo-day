import mysql.connector as mysql
import pandas as pd
import json


# Store df_hotspots for faster access
def storeRakData():

    wallets = ['14rGU1TrF4BSp8151FuENYnDKcbEtK4BgnNQnPdYP5134MsnoC8',
     '12ywrqqzeNFwSMvCcaohpVdiwEeK4NZChtL9rs7dhKYd85fKG9U',
     '13RSEY9QahRmH8w1MPzdCc2F8H6j7CKy9n2euiYGATq478Lkgzp',
     '145FvYMasJwaabPDBDe3A5NipXPZ75dAtdgzPNUyNqwAh3GjP4V',
     '1361Szja8dmX4cF2qWaYiNscpvtJmoHYkAFzQbfBCM4GyKDt6aa',
     '1426ztB1kLRT7DSu24JJFKPEtqMvJ55kWeQEBThFVGZe55jCY2a']


    hotspots = pd.DataFrame()

    for w in wallets:
        url = "https://api.helium.io/v1/accounts/"+w+"/hotspots"
        response = json_normalize(r.get(url).json(),'data')
        hotspots = hotspots.append(response)

    addresses = hotspots['address'].to_list()

    mydb = mysql.connect(host="neodbinstance.cqieshqdcqmd.us-east-2.rds.amazonaws.com",user="neoadmin",password="mycelium1",database="neodb")

    # Truncate table to populate it with fresh data from API
    mycursor = mydb.cursor()
    sql = "TRUNCATE TABLE hotspots"
    mycursor.execute(sql)
    mydb.commit()
    mycursor.close()
    mydb.close()


    mydb = mysql.connect(host="neodbinstance.cqieshqdcqmd.us-east-2.rds.amazonaws.com",user="neoadmin",password="mycelium1",database="neodb")
    for x in addresses:
        row = hotspots[hotspots['address']==x].reset_index()
        addr = x
        name = row['name'][0]
        status = row['status.online'][0]
        city = row['geocode.short_city'][0]
        mycursor = mydb.cursor()
        sql = "insert into hotspots (address, name, status, city) values (%s, %s, %s, %s)"
        val = (addr, name, status, city)
        mycursor.execute(sql,val)
        mydb.commit()
        mycursor.close()
    mydb.close()