from datetime import date, datetime, timedelta, timezone
import requests
import tweepy
import schedule #Convert time to GMT to Central https://greenwichmeantime.com/time/to/gmt-central/
import time
import tweepy
import mysql.connector as mysql
# import pandas as pd
import json


# Store df_hotspots for faster access
# def storeRakData():

#     wallets = ['14rGU1TrF4BSp8151FuENYnDKcbEtK4BgnNQnPdYP5134MsnoC8',
#      '12ywrqqzeNFwSMvCcaohpVdiwEeK4NZChtL9rs7dhKYd85fKG9U',
#      '13RSEY9QahRmH8w1MPzdCc2F8H6j7CKy9n2euiYGATq478Lkgzp',
#      '145FvYMasJwaabPDBDe3A5NipXPZ75dAtdgzPNUyNqwAh3GjP4V',
#      '1361Szja8dmX4cF2qWaYiNscpvtJmoHYkAFzQbfBCM4GyKDt6aa',
#      '1426ztB1kLRT7DSu24JJFKPEtqMvJ55kWeQEBThFVGZe55jCY2a']


#     hotspots = pd.DataFrame()

#     for w in wallets:
#         url = "https://api.helium.io/v1/accounts/"+w+"/hotspots"
#         response = json_normalize(r.get(url).json(),'data')
#         hotspots = hotspots.append(response)

    # addresses = hotspots['address'].to_list()

    # mydb = mysql.connect(host="neodbinstance.cqieshqdcqmd.us-east-2.rds.amazonaws.com",user="neoadmin",password="mycelium1",database="neodb")

    # Truncate table to populate it with fresh data from API
    # mycursor = mydb.cursor()
    # sql = "TRUNCATE TABLE hotspots"
    # mycursor.execute(sql)
    # mydb.commit()
    # mycursor.close()
    # mydb.close()




datetime_object = datetime.now()

today = date.today()

print ('Today: ', today)
print('Launching weather sequences...')

# helium = 'https://api.datacake.co/v1/devices/c444cab6-3047-4146-ab6b-6c48b015f8d3/historic_data/?fields=TEMPERATURE,HUMIDITY,PRESSURE,GAS&resolution=raw&timeframe_start='+str(today)+'T10:39:00Z&timeframe_end='+str(today)+'T10:00:00Z'
# ttn  = 'https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=HUMIDITY&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z'
#print('Helium API Request: ', helium)
#print('TTN API Request: ', ttn)

#Test Bot Auth Keys
consumer_key = '8qIb6bcUKOcoB6IdUJfhmSnUQ' # api key
consumer_secret = 'ztj4joQrbtcILn7SqvqRBSJEv7m2E5YK08jH8ctyblWfyUWzMq' # api passw
key = '1377293227896811521-laaHsLfwrBDY6s3j37bfjxAlURBgJU' # consumer key
secret = 'qcqGKjWFcBMmtQnjaggijzAcuGswEJieija5EWUNQ6vKA' # consumer password

# Authentication with Twitter
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(key, secret)
api = tweepy.API(auth)


#API KEYS FROM DATACAKE
#729485743856025622>: c444cab6-3047-4146-ab6b-6c48b015f8d3
#TTN: f3f0ac77-eb94-40e1-bd03-31a151ec92f5
#TTN DEMO DAY IOT FOR BALLERS: eced386a-7bac-4e23-ad38-9515135bd650
def datacake_db():
  r = requests.get('https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=HUMIDITY&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z', headers={'Authorization': 'Token ceede0ee65580ba31fac7b5342295f738c0bcab0'})
  # r = requests.get('https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=TEMPERATURE,HUMIDITY,PRESS,LIGHT&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z', headers={'Authorization': 'Token ceede0ee65580ba31fac7b5342295f738c0bcab0'})
  print(r)
  data = r.json()
  time_format = "%Y-%m-%dT%H:%M:%SZ"
  data = sorted(data, reverse=True, key=lambda x: datetime.strptime(x['time'], time_format))
  print(data)
  print("Time:",data[-1]['time'])
  print("hum:",data[-1]['HUMIDITY'] )
  # print("hum:",data[-1]['TEMPERATURE'] )
  hum = data[-1]['HUMIDITY']
  print("HUMIDITY = ", hum)
  light = 1
  temp = 100
  pressure = 21

  mydb = mysql.connect(host="neodbinstance.cqieshqdcqmd.us-east-2.rds.amazonaws.com",user="neoadmin",password="mycelium1",database="neodb")
  mycursor = mydb.cursor()
  # sql = "insert into w_rak_demo (temperature, humidity, pressure, light) values (%s, %s, %s, %s)"
  # sql = "insert into w_rak_demo2 (humidity, timestamp) values (%s, %s)"
  sql="INSERT INTO w_rak_demo4 (humidity, accessed) values (%s,%s)"
  timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
  # val = (hum, "yo")
  mycursor.execute(sql, (hum, timestamp))
  # mycursor.execute("insert into w_rak_demo2 (humidity) values (1)")
  mydb.commit()
  mycursor.close()

  mydb.close()

while True:
  datacake_db()
  time.sleep(20)

    # print("Temperature:",data[-1]['TEMPERATURE'])
    # print("Light:",data[-1]['LIGHT'])
    # print("PRESSURE:",data[-1]['PRESS'])
    # print("WIND:",data[-1]['WIND'])

# #Weather Variables
    # time1 = "Time:",data[-1]['time']
    # time1 = float(next)(i for i in data if i["time"] is not None)
    # print(time1, " = time print")
    # hum = float(data[-1]["HUMIDITY"])
    # hum = float(next(v for i in data if (v := i["HUMIDITY"]) is not None))
    # print(hum)
    # temp = float(next(v for i in data if (v := i["TEMPERATURE"]) is not None))
    # print(temp)
    # light = float(next(v for i in data if (v := i["LIGHT"]) is not None))
    # print(light)
    # pressure = float(next(v for i in data if (v := i["PRESS"]) is not None))
    # print(pressure)
#     # wind = float(next(v for i in data if (v := i["WIND"]) is not None))
#     # print(wind)

# \Light: {light:,.0f} hms \nPressure: {pressure:,.0f} KPa

    # statusTemp_Hum = f"Humidity: {hum:.0f}% \nTemperature: {temp:.0f} °F"
  
  
    # status = f"Humidity: {hum:.0f}% \nTemperature: {temp:.0f} °F \Light: {light:,.0f} hms \nPressure: {pressure:,.0f} KPa"
    # api.update_status(status)
    # print(statusTemp_Hum)
    # api.update_status(statusTemp_Hum)

# rak_demo_db()

# while True:
#   rak_demo_db()
#   time.sleep(20)
