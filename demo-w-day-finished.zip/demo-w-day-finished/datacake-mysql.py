from datetime import date, datetime, timedelta, timezone
import requests
import tweepy
import schedule #Convert time to GMT to Central https://greenwichmeantime.com/time/to/gmt-central/
import time
import tweepy

datetime_object = datetime.now()

today = date.today()

print ('Today: ', today)
print('Launching weather sequences...')

# helium = 'https://api.datacake.co/v1/devices/c444cab6-3047-4146-ab6b-6c48b015f8d3/historic_data/?fields=TEMPERATURE,HUMIDITY,PRESSURE,GAS&resolution=raw&timeframe_start='+str(today)+'T10:39:00Z&timeframe_end='+str(today)+'T10:00:00Z'
ttn  = 'https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=TEMPERATURE,HUMIDITY,PRESSURE,LIGHT&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z'
#print('Helium API Request: ', helium)
#print('TTN API Request: ', ttn)

#Test Bot Auth Keys
consumer_key = '8qIb6bcUKOcoB6IdUJfhmSnUQ' # api key
consumer_secret = 'ztj4joQrbtcILn7SqvqRBSJEv7m2E5YK08jH8ctyblWfyUWzMq' # api passw
key = '1377293227896811521-laaHsLfwrBDY6s3j37bfjxAlURBgJU' # consumer key
secret = 'qcqGKjWFcBMmtQnjaggijzAcuGswEJieija5EWUNQ6vKA' # consumer password

# Authentication with Twitter
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(key, secret)
api = tweepy.API(auth)

#729485743856025622>: c444cab6-3047-4146-ab6b-6c48b015f8d3
#TTN: f3f0ac77-eb94-40e1-bd03-31a151ec92f5
def rak_demo_db():
    r = requests.get('https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=TEMPERATURE,HUMIDITY,PRESSURE,LIGHT&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z', headers={'Authorization': 'Token ceede0ee65580ba31fac7b5342295f738c0bcab0'})
    # r = requests.get('https://api.datacake.co/v1/devices/eced386a-7bac-4e23-ad38-9515135bd650/historic_data/?fields=TEMPERATURE,HUMIDITY&resolution=raw&timeframe_start='+str(today)+'T00:00:00Z&timeframe_end='+str(today)+'T23:59:59Z', headers={'Authorization': 'Token ceede0ee65580ba31fac7b5342295f738c0bcab0'})

    data = r.json()
    time_format = "%Y-%m-%dT%H:%M:%SZ"
    data = sorted(data, reverse=True, key=lambda x: datetime.strptime(x['time'], time_format))
    print(data)
    print("Time:",data[-1]['time'])
    print("Humidity:",data[-1]['Hum'] )
    print("Temperature:",data[-1]['TEMPERATURE'])
    print("Light:",data[-1]['LIGHT'])
    print("PRESSURE:",data[-1]['PRESSURE'])
    # print("WIND:",data[-1]['WIND'])

# #Weather Variables
    time1 = "Time:",data[-1]['time']
    #time1 = float(next)(i for i in data if i["time"] is not None)
    print(time1)
    #hum = float(data[-1]["HUMIDITY"])
    hum = float(next(v for i in data if (v := i["HUMIDITY"]) is not None))
    print(hum)
    temp = float(next(v for i in data if (v := i["TEMPERATURE"]) is not None))
    print(temp)
    light = float(next(v for i in data if (v := i["LIGHT"]) is not None))
    print(light)
    pressure = float(next(v for i in data if (v := i["PRESS"]) is not None))
    print(pressure)
#     # wind = float(next(v for i in data if (v := i["WIND"]) is not None))
#     # print(wind)

# \Light: {light:,.0f} hms \nPressure: {pressure:,.0f} KPa

    statusTemp_Hum = f"Humidity: {hum:.0f}% \nTemperature: {temp:.0f} °F"
  
    # status = f"Humidity: {hum:.0f}% \nTemperature: {temp:.0f} °F \Light: {light:,.0f} hms \nPressure: {pressure:,.0f} KPa"
    # api.update_status(status)
    print(statusTemp_Hum)
    api.update_status(statusTemp_Hum)

while True:
  rak_demo_db()
  time.sleep(14400)
